# Разбор клипов из Google Flow / Veo (имена любые).
#   python tools/clips.py <рабочая_папка> <папка_с_клипами>
# Делает: <раб>/clips.json (имя, длительность, fps, размер, есть ли звук) и <раб>/clips_sheet.jpg —
# лист кадров: по строке на клип, кадры начало / 25% / середина / 75% / конец, подписи номеров.
import json, os, shutil, subprocess, sys, glob

EXT = ('.mp4', '.mov', '.webm', '.mkv')


def find(tool):
    p = shutil.which(tool)
    if p:
        return p
    base = os.path.expandvars(r'%LOCALAPPDATA%\Microsoft\WinGet\Packages')
    for root, _, files in os.walk(base):
        if tool + '.exe' in files:
            return os.path.join(root, tool + '.exe')
    sys.exit(f'{tool} не найден — поставь FFmpeg (winget install Gyan.FFmpeg / brew install ffmpeg)')


FF, FP = find('ffmpeg'), find('ffprobe')
work, src = sys.argv[1], sys.argv[2]
os.makedirs(os.path.join(work, 'frames'), exist_ok=True)
files = sorted(p for p in glob.glob(os.path.join(src, '*')) if p.lower().endswith(EXT))
if not files:
    sys.exit('В папке нет видео-клипов')
info = []
for i, p in enumerate(files, 1):
    j = json.loads(subprocess.run([FP, '-v', 'error', '-show_entries', 'format=duration:stream=codec_type,width,height,r_frame_rate', '-of', 'json', p], capture_output=True, text=True).stdout)
    v = next(s for s in j['streams'] if s['codec_type'] == 'video')
    num, den = v['r_frame_rate'].split('/')
    d = float(j['format']['duration'])
    info.append({'n': i, 'file': os.path.basename(p), 'dur': round(d, 2), 'fps': round(float(num) / float(den), 2), 'w': v['width'], 'h': v['height'], 'audio': any(s['codec_type'] == 'audio' for s in j['streams'])})
    for k, frac in enumerate((0.02, 0.25, 0.5, 0.75, 0.97)):
        out = os.path.join(work, 'frames', f'c{i:02d}_{k}.jpg')
        subprocess.run([FF, '-v', 'error', '-y', '-ss', f'{d * frac:.2f}', '-i', p, '-frames:v', '1', '-vf', 'scale=-2:220', out])
    print(f"{i:02d}  {info[-1]['dur']:5.2f} с  {info[-1]['fps']} fps  {v['width']}x{v['height']}  <- {info[-1]['file']}")
json.dump(info, open(os.path.join(work, 'clips.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

# лист: строки = клипы, 5 кадров в строке + номер
from PIL import Image, ImageDraw
rows = []
for c in info:
    ims = [Image.open(os.path.join(work, 'frames', f"c{c['n']:02d}_{k}.jpg")) for k in range(5)]
    w = sum(im.width for im in ims) + 90
    row = Image.new('RGB', (w, 230), (40, 40, 44))
    ImageDraw.Draw(row).text((14, 100), f"#{c['n']:02d}\n{c['dur']}s", fill=(255, 255, 255))
    x = 90
    for im in ims:
        row.paste(im, (x, 5)); x += im.width
    rows.append(row)
W = max(r.width for r in rows)
sheet = Image.new('RGB', (W, 230 * len(rows)), (40, 40, 44))
for i, r in enumerate(rows):
    sheet.paste(r, (0, i * 230))
sheet.save(os.path.join(work, 'clips_sheet.jpg'), quality=85)
print('Лист кадров:', os.path.join(work, 'clips_sheet.jpg'))
