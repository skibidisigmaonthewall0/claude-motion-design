// Word-level speech-to-text on your own computer (whisper.cpp via Remotion). No API, no cost.
// usage: node work/tools/transcribe.mjs <audio16k.wav> <model: medium|small.en|small> <language: ru|en|auto> <out.json>
// Make the wav first: ffmpeg -i video.mp4 -vn -ar 16000 -ac 1 -c:a pcm_s16le work/audio16k.wav
import path from 'path';
import fs from 'fs';
import {installWhisperCpp, downloadWhisperModel, transcribe, toCaptions} from '@remotion/install-whisper-cpp';
const [input, model = 'medium', language = 'ru', out = 'work/words.json'] = process.argv.slice(2);
const to = path.join(process.cwd(), 'whisper.cpp');
await installWhisperCpp({to, version: '1.5.5'});
await downloadWhisperModel({model, folder: to});
const opts = {inputPath: path.resolve(input), whisperPath: to, whisperCppVersion: '1.5.5', model, tokenLevelTimestamps: true};
if (!model.endsWith('.en')) opts.language = language;
const res = await transcribe(opts);
const {captions} = toCaptions({whisperCppOutput: res});
// merge sub-word tokens into words: [{w, t, e}]
const words = []; let cur = null;
for (const c of captions) { if (!c.text.trim()) continue; if (c.text.startsWith(' ') || !cur) { cur = {w: c.text.trim(), t: c.startMs / 1000, e: c.endMs / 1000}; words.push(cur); } else { cur.w += c.text; cur.e = c.endMs / 1000; } }
fs.writeFileSync(out, JSON.stringify(words, null, 1));
console.log(words.length, 'words ->', out);
